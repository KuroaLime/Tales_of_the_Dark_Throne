#pragma once

#define IDB_SMAP_BACKGROUND             102
#define IDB_BITMAP1                     103
#define IDB_BITMAP2                     104
#define IDB_UI_MOUSECUSOR               104
#define IDB_BITMAP3                     105

#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
