#include "UContainerWidget.h"
#include <algorithm>

UContainerWidget::UContainerWidget()
{
}

UContainerWidget::~UContainerWidget()
{
	ClearChildren(true);
}

void UContainerWidget::Init() {

}
void UContainerWidget::Draw(HDC hMemDC, HDC hMemDC1) {
	if (!bVisible) return;

	// 배경 그림 그리기
	if (!bBitmap.empty()) {
		HBITMAP temp = (HBITMAP)SelectObject(hMemDC1, bBitmap[CurAni]);
		TransparentBlt(hMemDC, Loc.x - Size.sX / 2, Loc.y - Size.sY / 2, Size.sX, Size.sY, hMemDC1, 0, 0, bMapinfo[CurAni].bmWidth, bMapinfo[CurAni].bmHeight, TransColor);
		SelectObject(hMemDC1, temp);
	}

	for (int i = 0; i < (int)Contents.size(); i++) {
		Contents[i]->Draw(hMemDC, hMemDC1);
	}
}
void UContainerWidget::Update() {
	if (AniCount > 0) {
		CurAni = (CurAni + 1) % AniCount;
	}

	for (int i = 0; i < (int)Contents.size(); i++) {
		Contents[i]->Update();
	}
}
void UContainerWidget::UpdateMouseHover(int MouseX, int MouseY) {
	if (!bVisible) {
		IsPointed = false;
		for (auto child : Contents) child->UpdateMouseHover(MouseX, MouseY);
		return;
	}

	IsPointed = ContainsPoint(MouseX, MouseY);

	for (auto child : Contents) {
		child->UpdateMouseHover(MouseX, MouseY);
	}
}

UWidget* UContainerWidget::FindWidgetUnderMouse(int MouseX, int MouseY) {
	if (!bVisible) return nullptr;

	for (int i = (int)Contents.size() - 1; i >= 0; i--) {
		UWidget* FindChild = Contents[i]->FindWidgetUnderMouse(MouseX, MouseY);
		if (FindChild != nullptr)
			return FindChild;
	}

	if (ContainsPoint(MouseX, MouseY))
		return this;

	return nullptr;
}

void UContainerWidget::AddChild(UWidget* NewChild) {
	if (NewChild) {
		Contents.push_back(NewChild);
	}
};

void UContainerWidget::RemoveChild(UWidget* Child, bool bDelete)
{
	auto it = std::find(Contents.begin(), Contents.end(), Child);
	if (it != Contents.end())
	{
		UWidget* pWidget = *it;
		Contents.erase(it);
		if (bDelete && pWidget)
		{
			delete pWidget;
		}
	}
}

void UContainerWidget::ClearChildren(bool bDelete)
{
	if (bDelete)
	{
		// 복사본을 만들어 순회하며 삭제 (삭제 과정에서 Contents가 변할 가능성 대비)
		std::vector<UWidget*> temp = Contents;
		Contents.clear(); 
		for (auto child : temp)
		{
			if (child) delete child;
		}
	}
	else
	{
		Contents.clear();
	}
}
